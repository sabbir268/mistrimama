<style>
.rawstyle{
  margin-left: 50px !important;
  margin:0px
}

@media only screen and (max-width: 600px) {
  .rawstyle{
    margin-left: 0px !important;
    margin:0px
  }
}
</style>
<div class="main-bar clearfix " style="    background: #ffffff96;">
    <div class="container">
        <div class="logo-header mostion rawstyle" style="">
            <div class="logo-header-inr"><a href="{{asset('/')}}"> <img style="    max-width: 100%;height: 23%;" src='{{ getConfigValue("home_logo") }}'
                        alt="MISTRI MAMA" title="MISTRI MAMA"> </a>
            </div>
        </div>
        <button data-target=".header-nav" data-toggle="collapse" type="button"
            class="navbar-toggle collapsed nav-top-slide-btn">
            <span class="sr-only">
                Toggle navigation </span> <span class="icon-bar"></span> <span class="icon-bar"></span>
            <span class="icon-bar"></span> </button>
        <button type="button" class="navbar-toggle nav-left-slide-btn">
            <span class="sr-only">
                Toggle navigation </span> <span class="icon-bar"></span> <span class="icon-bar"></span>
            <span class="icon-bar"></span> </button>
        <div class="header-nav navbar-collapse collapse ">

            @if(!Auth::check())
            <div class="extra-nav">
                <div class="extra-cell">
                    <a href="javascript:void(0);" class="btn btn-border btn-sm" data-redirect="yes" data-action="login"
                        data-toggle="modal" data-target="#login-Modal"><i class="fa fa-user"></i>
                        Login
                    </a>
                </div>
                <div class="extra-cell">
                    <a href="javascript:void(0);" class="btn btn-border btn-sm" data-toggle="modal" data-action="signup"
                        data-target="#login-Modal"><i class="fa fa-plus"></i>
                        Sign up
                    </a>
                </div>
            </div>
            @else
            <ul id="primary-menu" class="nav navbar-nav">
                <li id="menu-item-20"
                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-20">
                    <a>{{ Auth::user()->name }}</a>
                    <ul class="sub-menu">
                        <li id="menu-item-1673"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1673">
                            <a href="{{ route('dashboard') }}">My Account</a>
                        </li>
                        <li id="menu-item-1668"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1668">
                            <a href="{{ route('logout') }}" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">Logout</a>
                        </li>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            {{ csrf_field() }}
                        </form>
                    </ul>
                </li>
            </ul>
            @endif


            <ul id="primary-menu" class="nav navbar-nav">
                <li id="menu-item-2697"
                    class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-2697">
                    <a href="{{url('/')}}">Home</a></li>
                <li id="menu-item-2695" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2695">
                    <a href="{{url('/')}}#about">About Us</a>
                </li>
                <li id="menu-item-2695" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2695">
                    <a href="{{url('/')}}#services">Our Service</a>
                </li>
                <li id="menu-item-2275"
                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2275">
                    <a href="#">Book Now</a>
                    <ul class="sub-menu">
                        <li id="menu-item-2276"
                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2276">
                            <a href="">Book Now</a>
                            <ul class="sub-menu">
                                <li><a href="{{url('/electrical')}}">Electrical Services</a></li>
                                <li><a href="{{url('/plumbing')}}">Plumbing Services</a></li>
                                <li><a href="{{url('/generator')}}">Generator Services</a></li>
                                <li><a href="{{url('/ict')}}">IT Services</a></li>
                                <li><a href="{{url('/cctv')}}">CCTV Services</a></li>
                                <li><a href="{{url('/air-conditional')}}">AC Services</a></li>
                            </ul>
                        </li>
                        <li id="menu-item-2277"
                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2277">
                            <a href="{{ asset('assets/Grow_with_us_(B2B).pdf') }}">Book For Corporate</a>
                        </li>
                    </ul>
                </li>
                <li id="menu-item-18" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-18">
                    <a href="{{url('/contact')}}">Contact US</a>
                </li>
            </ul>
        </div>
        <div class="body-overlay" style="display: none;"></div>
    </div>
</div>