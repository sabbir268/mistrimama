@extends('admin.cms.template') 
@section('body')

<h1 class="page-title">Booking
    <small></small>
    <!--    <a href="{{ route('cms.create') }}" class="btn btn-primary float-right"> Create </a>-->
</h1>
<div class="row">
    <div class="col-md-12">
        @foreach (['danger', 'warning', 'success', 'info'] as $msg) @if(Session::has('alert-' . $msg))
        <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }}</p>
        @endif @endforeach

        <div class="portlet box green">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="fa fa-cogs"></i>Service History</div>
                </div>
        
        
                <div class="portlet-body flip-scroll">
                    <table class="table table-bordered table-striped table-condensed flip-content">
                        <thead class="flip-content">
                            <tr>
                                <th>Order No</th>
                                <th>Category</th>
                                <th>Client Name</th>
                                <th>Date/Time</th>
                                <th>Providers</th>
                                <th>Comrade</th>
                                <th class="align-center">View</th>
                                <th class="align-center">Status </th>
                            </tr>
                        </thead>
                        <tbody>
                            @if ($allorders)
                            @foreach ($allorders as $actorder)
                            <tr>
                                <td>{{ $actorder->order->order_no }}</td>
                                <td>{{ $actorder->order->category->name }}</td>
                                <td>{{ $actorder->user->name }}</td>
                                <td>{{ $actorder->order->order_date }}/{{ $actorder->order->order_time }}</td>
                                <td>{{ $actorder->provider->name }}</td>
                                <td>{{ $actorder->comrade->c_name }}</td>
                                <td class="align-center"><a class="btn btn-primary" data-toggle="modal" data-target="#view-act-{{$actorder->id}}" data-item="{{ $actorder->id }}">
                                            View Details
                                        </a>
                                </td>
                                <td class="align-center">
                                        @if($actorder->order->status == 1)
                                        <span class="text-warning">Comrade On The way</span>
                                        @endif  
                                        @if($actorder->order->status == 2)
                                                <span class="text-danger">Comrade working on service.</span>
                                        @endif
                                        @if($actorder->order->status == 3)
                                                <span class="text-success">Comrade has finish his job. And witing for payment.</span>
                                        @endif
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    {{$allorders->links()}}
                    
                    @endif
                </div>
            </div>
    </div>
</div>
@endsection