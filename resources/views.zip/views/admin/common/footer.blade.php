<div class="page-footer-inner"> <?= date("Y") ?> &copy; {{ config('app.name', 'Laravel') }}</div>
<div class="scroll-to-top">
    <i class="icon-arrow-up"></i>
</div>