<div class="mobile-menu-left-overlay"></div>

<!--.side-menu-->