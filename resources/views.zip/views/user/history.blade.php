@extends('layouts.main-dash')

@section('styles')
<link rel="stylesheet" href="{{asset('dashboard/css/lib/lobipanel/lobipanel.min.css')}}">
<link rel="stylesheet" href="{{asset('css/separate/vendor/lobipanel.min.css')}}">
<link rel="stylesheet" href="{{asset('css/lib/jqueryui/jquery-ui.min.css')}}">
<link rel="stylesheet" href="{{asset('css/separate/pages/widgets.min.css')}}">    
@endsection

@section('topbar')
@include('user.topbar')
@endsection

@section('sidebar')
@include('user.sidebar')
@endsection


@section('content')
    <div class="col-md-12">
            <section class="box-typical box-typical-dashboard panel panel-default scrollable">
            <header class="box-typical-header panel-heading">
                    <h3 class="panel-title pt-1"> Services History</h3>
            </header>
            <div class="box-typical-body m-1">
                <table class="table table-bordered">
                    <tr>
                        <th rowspan="2"><div>Sl.</div></th>
                        <th rowspan="2"><div>Orders#</div></th>
                        <th rowspan="1"><div>Services</div></th>
                        <th rowspan="2"><div>Date</div></th>
                        <th rowspan="2"><div>Time</div></th>
                        <th rowspan="2"><div>Order Place Time </div></th>
                    </tr>
                    <tr>

                    </tr>
                    <?php $i = 1 ?>
                    @foreach ($orders as $order )
                        <tr>
                            <th><div>{{$i}} </div></th>
                            <th><div>{{$order->order_no}}</div></th>
                            <th>
                                <div>
                                    <?php $services = $order->bookings()->get()?>
                                     @foreach($services as $service)
                                       <li><a href="#" class="btn-link">{{$service->sub_category->first()->name}}</a></li>
                                    @endforeach
                                </div>
                            </th>
                            <th><div>{{$order->order_date}}</div></th>
                            <th><div>{{$order->order_time}}</div></th>
                            <th><div>{{$order->created_at}}</div></th>
                            <?php $i++ ?>
                        </tr> 
                    @endforeach
                    
                </table>
            </div><!--.box-typical-body-->
            {{ $orders->links() }}
        </section><!--.box-typical-dashboard-->
    </div>

               
@endsection

@section('scripts')
<script type="text/javascript" src="{{asset('dashboard/js/lib/jqueryui/jquery-ui.min.js')}}"></script>
<script type="text/javascript" src="{{asset('dashboard/js/lib/lobipanel/lobipanel.min.js')}}"></script>
<script type="text/javascript" src="{{asset('dashboard/js/lib/match-height/jquery.matchHeight.min.js')}}"></script>
<script type="text/javascript" src="http://www.gstatic.com/charts/loader.js"></script>

<script>    
    $(document).ready(function() {
            $('.panel').each(function () {
                try {
                    $(this).lobiPanel({
                        sortable: true
                    }).on('dragged.lobiPanel', function(ev, lobiPanel){
                        $('.dahsboard-column').matchHeight();
                    });
                } catch (err) {}
            });
</script>
@endsection

