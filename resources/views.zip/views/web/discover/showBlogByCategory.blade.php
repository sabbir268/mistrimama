@if($models)
<?php foreach($models as $model){ ?>
<div class="col-md-4 col-sm-12">
<div class="card"  style="border: 2px solid #eee;">
   <img class="card-img-top img-fluid" style="width: 100%; height:230px;" src="{{url('images/blogs/thumbnail')}}/{{$model->image}}">
  <div class="card-body" style="padding:10px;">
    <h5 class="card-title" style="margin-top: 10px;font-weight: 700;text-align: justify;">
         {{ $model->title }}
    </h5>
            <p class="card-text text-center" style="text-align:justify"><?php echo substr($model->content, 0,250); ?></p>
             <a href="{{url('showOneBlog/')}}/{{$model->id}}">Learn more ...</a>
    </div>
  </div>
</div>
<?php } ?>
@else
<br>
<h4 class="text text-center" style="font-family:Varela Round', sans-serif !important;text-align:center;padding-top:100px;margin-top:20px;"><?php echo "There is no records related this category"; ?><h4>
@endif

