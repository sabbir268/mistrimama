@extends('layouts.web')
@section('content')
<section class="big-title">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h2>BLOG</h2>
            </div>
        </div>
    </div>
</section>
<!-- /.big-title -->


<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <!-- Accordion -->
            <div class="panel-group" id="" role="tablist" aria-multiselectable="true">

                <center><h3 >Blog</h3></center>
 
              <?php foreach($models as $model){ 
                    ?>
                <h4>  {{ $model->title   }}</h4>
                <p style="margin-top: 10px;">  <?php echo  $model->content ?></p>
            <?php } ?>

            </div>
</div>
</div>
</div>
@endsection


