 @foreach($cluster_response as $data)    
   <option value="{{$data->id}}">{{$data->name}}</option>
@endforeach