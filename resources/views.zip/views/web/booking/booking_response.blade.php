                       
                       <?php $number = count(Session::get('mycat'));?>
                                                    @if($number>0)   
                                                   @for($i=0; $i<$number;$i++)
                                       
                                                    <div class="col-xs-12" style="border-bottom:1px solid #CCCCCC">
                                                    <b class="pull-left">
                                                     <p style="font-size:15px;color: #CCCCCC">  {{Session::get('mycatName')[$i]}}</p>
                                                     <small>Price | {{Session::get('mycat_min_price')[$i]}} - {{Session::get('mycat_max_price')[$i]}}</small>
                                                     </b> 
                                                        <b class="pull-right">
                                                      <button disabled="true" class="btn btn-danger btn-xs " >Quantity |   {{Session::get('myqty')[$i]}}</button>
                                                      <a href="{{url('Booking/service-categeory-delete')}}/{{$i}}/{{$i}}" class="btn btn-danger btn-xs deleteBtn" >X</a>
                                                     </b>
                                                 </div>
                                                   @endfor
                                                  @endif


<script src="{{ asset('assets/newfront/js/vendor/jquery-1.12.4.min.js') }}"></script>
<script src="{{ asset('assets/newfront/js/vendor/bootstrap.min.js') }}"></script>
<script type="text/javascript">
  $('.deleteBtn').on('click',function(){
     $.ajax({
      url:$(this).attr('href'),
      type:'get',
      dataType:'html',
      success:function(response){
              $('.show_more_services_category').html(response);
      }
     });

     return false;
  });
</script>
