@extends('layouts.application')
@section('content')

<!--header close-->
<div class="headershadow paddtb">
    <section class="genSection dashboardPage">
        <div class="container">
            <div class="dashboardInner">
                <div class="dashboardLeft">
                    @include('users.sidebar')

                </div>	
                <div class="dashboardRight">
                    <div class="accountPage payment_form_stripe">
                        {!! Form::model($users, ['method' => 'POST','route' => ['recharge'],'id'=>'customer_register' ]) !!}
                        <div class="personalInfo paddB">
                            <h3>Resume Subscription</h3>
                            <div class="infoForm">
                                <div class="formRow">
                                    <div class="carderror error centeralign fullWidth paddBottm" role="alert">
                                            <span class="message"><?= $errors->first('stripetoken'); ?></span>
                                        </div>
                                        <div class="form-group row membership_plan resumesubscription">
                                            {{ $subscription->description }}
                                            {!! Form::hidden('stripetoken', null, array('id' => 'stripetoken')) !!}
                                        </div>
                                        
                                    
                                </div>

                                <div class="formRow">
                                    <label>Card Number</label>
                                    <div class="inputBox">
                                        <div id="card-number" class="form-wrap cradbg"></div>
                                        
                                    </div>
                                </div>
                                <div class="formRow">
                                    <label>EXP Date</label>
                                    <div class="inputBox">
                                        <div id="card-expiry" class="form-wrap"></div>
                                    </div>
                                </div>
                                <div class="formRow">
                                    <label>CVV Code</label>
                                    <div class="inputBox">
                                        <div id="card-cvc" class="form-wrap"></div>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" value="Next"  data-tid="elements_examples.form.pay_button" id="submirBtn" class="btn btn-default redc updateBtn">
                            <span id="btn_text">Pay now</span>
                            <i class="fa fa-arrow-right payment_arrow"></i>
                            <i style="display:none" class="fa fa-circle-o-notch rotateIcon"></i>
                        </button>
                        </div>
                        
                        <a style="display: none" value="Next" class="btn btn-default geryc reset">
                            Cancel <i class="fa fa-arrow-right"></i>
                        </a>
                        {!! Form::close() !!}
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
@endsection
@section('pagescript')
<script src="https://js.stripe.com/v3/"></script>
<script src="{{asset('js/stripe/index.js') }}" data-rel-js></script>
<script src="{{asset('js/stripe/example2.js') }}" data-rel-js></script>
@endsection