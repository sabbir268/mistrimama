{{--
<div id="loginModel" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content col-xs-12 col-sm-12 col-md-12 col-lg-12">

            <div class="modal-body col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="signin-form col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <form method="POST" action="javascript:void(0)" onsubmit="return false" id="login-popup-form">
                        @csrf

                        <h2>Sign in</h2>
                        <p class="hint-text">Sign in with your social media account</p>
                        <div class="social-btn text-center">
                            <a href="{{route('social-login',['provider'=>'facebook'])}}" class="btn btn-primary btn-lg" title="Facebook">
                                <center><i class="fa fa-facebook" style="margin-left:-3px;"></i></center>
                            </a>
                            <a href="{{route('social-login',['provider'=>'LinkedIn'])}}" class="btn btn-info btn-lg" title="Twitter">
                                <center><i class="fa fa-twitter" style="margin-left:-1px;"></i></center>
                            </a>
                            <a href="{{route('social-login',['provider'=>'Google'])}}" class="btn btn-danger btn-lg" title="Google">
                                <center><i class="fa fa-google" style="margin-left:-1px;"></i></center>
                            </a>
                        </div>
                        <div class="or-seperator"><b>or</b></div>
                        <div class="form-group">
                            <input id="email" type="email" class="input-lg form-control{{ $errors->has('username') ? ' is-invalid' : '' }}" name="username"
                                placeholder="Enter Email Address" value="{{ old('username') }}" required autofocus>                            @if ($errors->has('email'))
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span> @endif
                        </div>
                        <div class="form-group">
                            <input id="password" type="password" class="input-lg form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" placeholder="Enter Password"
                                name="password" required> @if ($errors->has('password'))
                            <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span> @endif </div>
                        <div class="form-group">
                            <p class="login-response"></p>
                            <button type="submit" onclick="loginUserPopup()" class="btn btn-success btn-lg btn-block signup-btn">
                                {{ __('Login') }}
                            </button>
                        </div>
                        <div class="text-center small"><a href="#">Forgot Your password?</a></div>
                    </form>
                </div>
            </div>

        </div>

    </div>
</div>

<script>
    function loginUserPopup(){
        $.ajax({
        type: "POST",
                url: '{{ url("booking-login") }}',
                data: $("#login-popup-form").serialize(),
                dataType : 'JSON',
                success:function(data){
                if (data.status == 0){
                $(".login-response").html(data.message)
                } 
                else{
                location.href="user/profile";
                }

                }
        });
    }

</script>
--}}
<div class="modal fade login" id="loginModal">
    <div class="modal-dialog login animated">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Log in to your account</h4>
            </div>
            <div class="modal-body">
                <div class="box">
                    <div class="content">
                        <div class="social">
                            <a id="linkedin" class="circle linkedin" href="{{route('social-login', 'linkedin')}}">
                                <i class="fa fa-linkedin fa-fw"></i>
                            </a>
                            <a id="facebook_login" class="circle facebook" href="{{route('social-login', 'facebook')}}">
                                <i class="fa fa-facebook fa-fw"></i>
                            </a>
                        </div>

                        <div class="error"></div>
                        <div class="form loginBox">
                            <form method="post" action="{{route('user.do-login')}}" accept-charset="UTF-8">
                                {{csrf_field()}}
                                <input id="email" class="form-control" type="text" placeholder="Email" name="email">
                                <input id="password" class="form-control mb-2" type="password" placeholder="Password" name="password">
                                <select style="background-color: #e8f0fe;color: #000;" name="user_type" class="form-control" id="" required>
                                    <option value="">Chose User Type...</option>
                                    <option value="user">Client</option>
                                    <option value="esp">ESP</option>
                                    <option value="fsp">FSP</option>
                                    <option value="comrade">Comrade</option>
                                </select>

                                <input type="text" name="reason" id="reason" value="false" hidden>
                                <input class="btn btn-default btn-login mt-2" type="submit" value="Login">
                            </form>
                        </div>
                    </div>
                </div>
                <div class="box">
                    <div class="content registerBox" style="display:none;">
                        <div class="form">
                            <form method="post" action="{{route('user.do-register')}}" html="{:multipart=>true}" data-remote="true" accept-charset="UTF-8">
                                {{csrf_field()}}
                                <input id="name" class="form-control" type="text" placeholder="Full Name" name="name">
                                <input id="email" class="form-control" type="email" placeholder="Email" name="email">
                                <input id="phone_no" class="form-control" type="text" placeholder="Mobile Number" name="phone_no">
                                <input id="password" class="form-control" type="password" placeholder="Password" name="password">
                                <textarea id="address" rows="3" class="form-control" placeholder="Address" name="address"></textarea>
                                <input type="text" name="user_type" value="user" hidden>


                                <input type="text" name="reason" id="reason" value="false" hidden>
                                <input class="btn btn-default btn-register" type="submit" value="Create account" name="commit">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <div class="forgot login-footer">
                    <span>Looking to
                                 <a href="javascript: showRegisterForm();">create an account</a>
                            ?</span>
                </div>
                <div class="forgot register-footer" style="display:none">
                    <span>Already have an account?</span>
                    <a href="javascript: showLoginForm();">Login</a>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade login" id="loginModalOrder">
    <div class="modal-dialog login animated">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Log in to your account</h4>
            </div>
            <div class="modal-body">
                <div class="box">
                    <div class="content">
                        <div class="social">
                            <a id="linkedin" class="circle linkedin" href="{{route('social-login', 'linkedin')}}">
                                <i class="fa fa-linkedin fa-fw"></i>
                            </a>
                            <a id="facebook_login" class="circle facebook" href="{{route('social-login', 'facebook')}}">
                                <i class="fa fa-facebook fa-fw"></i>
                            </a>
                        </div>

                        <div class="error"></div>
                        <div class="form loginBox">
                            <form method="post" action="{{route('user.do-login')}}" accept-charset="UTF-8">
                                {{csrf_field()}}
                                <input id="email" class="form-control" type="text" placeholder="Email" name="email">
                                <input id="password" class="form-control mb-2" type="password" placeholder="Password" name="password">
                                <select style="background-color: #e8f0fe;color: #000;" name="user_type" class="form-control" id="" required>
                                    <option value="">Chose User Type...</option>
                                    <option value="user">Client</option>
                                    <option value="esp">ESP</option>
                                    <option value="fsp">FSP</option>
                                    <option value="comrade">Comrade</option>
                                </select>

                                <input type="text" name="reason" id="reason" value="true" hidden>
                                <input class="btn btn-default btn-login mt-2" type="submit" value="Login">
                            </form>
                        </div>
                    </div>
                </div>
                <div class="box">
                    <div class="content registerBox" style="display:none;">
                        <div class="form">
                            <form method="post" action="{{route('user.do-register')}}" html="{:multipart=>true}" data-remote="true" accept-charset="UTF-8">
                                {{csrf_field()}}
                                <input id="name" class="form-control" type="text" placeholder="Full Name" name="name">
                                <input id="email" class="form-control" type="email" placeholder="Email" name="email">
                                <input id="phone_no" class="form-control" type="text" placeholder="Mobile Number" name="phone_no">
                                <input id="password" class="form-control" type="password" placeholder="Password" name="password">
                                <textarea id="address" rows="3" class="form-control" placeholder="Address" name="address"></textarea>
                                <input type="text" name="user_type" value="user" hidden>


                                <input type="text" name="reason" id="reason" value="true" hidden>
                                <input class="btn btn-default btn-register" type="submit" value="Create account" name="commit">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <div class="forgot login-footer">
                    <span>Looking to
                                 <a href="javascript: showRegisterForm();">create an account</a>
                            ?</span>
                </div>
                <div class="forgot register-footer" style="display:none">
                    <span>Already have an account?</span>
                    <a href="javascript: showLoginForm();">Login</a>
                </div>
            </div>
        </div>
    </div>
</div>