<!DOCTYPE html>
<html>

<head lang="en">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Mistri Mama || Door step service provider</title>
	<link href="img/favicon.html" rel="icon" type="image/png">
	@csrf
	<link rel="stylesheet" href="{{asset('dashboard/css/lib/font-awesome/font-awesome.min.css')}}">
	<link rel="stylesheet" href="{{asset('dashboard/css/lib/bootstrap/bootstrap.min.css')}}">
	<link rel="stylesheet" href="{{asset('css/separate/vendor/bootstrap-daterangepicker.min.css')}}">
	<link rel="stylesheet" href="{{asset('dashboard/css/main.css')}}">
	<style>
		#preloader {
			position: fixed;
			left: 0;
			top: 0;
			z-index: 999;
			width: 100%;
			height: 100%;
			overflow: visible;
			background: #fff;
		}

		#square {
			position: absolute;
			top: 50%;
			left: calc(50% - 50px);
			transform: translate(-50%, -50%);
			width: 50px;
			height: 50px;
			background: #ff0;
			border: 4px solid #262626;
			box-sizing: border-box;
			animation: animate 1s linear infinite;
		}

		@keyframes animate {
			0% {
				transform-origin: bottom right;
				transform: translate(-50%, -50%) rotate(0deg) translateX(25px);
			}

			50% {
				transform-origin: bottom right;
				transform: translate(-50%, -50%) rotate(90deg);
			}

			100% {
				transform-origin: bottom right;
				transform: translate(-50%, -50%) rotate(90deg) translateY(25px);
			}
		}

	</style>

	@yield('styles')
</head>

<body onload="preload()" class="with-side-menu">
	<div id="fb-root"></div>
	<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v3.3">
	</script>

	@yield('topbar')

	<div class="mobile-menu-left-overlay"></div>
	@yield('sidebar')
	<div class="page-content">
		<div class="container-fluid p-0">
			@yield('content')
		</div>
		<!--.container-fluid-->

		<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
			{{ csrf_field() }}
		</form>
	</div>
	<!--.page-content-->

	<script src="{{asset('dashboard/js/lib/jquery/jquery-3.2.1.min.js')}}"></script>
	<script src="{{asset('dashboard/js/lib/popper/popper.min.js')}}"></script>
	<script src="{{asset('dashboard/js/lib/tether/tether.min.js')}}"></script>
	<script src="{{asset('dashboard/js/lib/bootstrap/bootstrap.min.js')}}"></script>
	<script src="{{asset('dashboard/js/plugins.js')}}"></script>

	@yield('scripts')

	<script src="{{asset('dashboard/js/app.js')}}"></script>

	<script>
		function preload() {
			//$('#preloader').fadeOut('slow', function () { $(this).remove(); $('.with-side-menu').show() });
			$('#preloader').hide();
        }
	</script>

</body>

</html>