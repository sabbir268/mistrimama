@extends('new_layout.template')
@section('content')
<div class="page-content">
  <!-- inner page banner -->
  <!-- Breadcrumb  Templates Start -->

  <div class="breadcrumb-row">
    <div class="container">
      <ul class="list-inline">
        <li><a href="../index.html">
            Home </a></li>
        <li>Signup</li>
      </ul>
    </div>
  </div>
  <!-- Breadcrumb  Templates End -->
  <!-- Left & right section start -->

  <div class="section-content profiles-content">
    <div class="container">
      <div class="row">
        <!-- Left part start -->
        <div class="col-md-12">
          <!-- Signup Template -->
          <!-- Content -->
          <!-- Left & right section start -->
          <div class="padding-20 margin-b-30  bg-white sf-rouned-box sf-register-page">
                <div id="customertab" class="tab-pane fade in active">
                  <form class="customer_registration_page" method="post" action="{{route('user.do-register')}}">
                    {{csrf_field()}}
                    <div class="customer-bx clearfix row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <input name="name" type="text" class="form-control" placeholder="Full Name">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <input name="phone_no" type="text" class="form-control" placeholder="Mobile Number">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <input name="email" type="email" class="form-control" placeholder="Email">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <input name="password" type="password" class="form-control" placeholder="Password">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <textarea name="address" rows="4" class="form-control" placeholder="Address"></textarea>
                        </div>
                      </div>
                      <input type="text" name="reason" value="true" hidden>
                      <input type="text" name="user_type" value="user" hidden>
                      <div class="col-md-12">
                        <input type="submit" class="btn btn-primary btn-block" name="user-register" value="Sign up" />
                      </div>
                    </div>
                  </form>

                  <style type="text/css">
                    .wp-social-login-connect-with {}

                    .wp-social-login-provider-list {}

                    .wp-social-login-provider-list a {}

                    .wp-social-login-provider-list img {}

                    .wsl_connect_with_provider {}
                  </style>

                  <div class="wp-social-login-widget">

                    <div class="wp-social-login-connect-with">Connect with:</div>

                    <div class="wp-social-login-provider-list">

                      <a rel="nofollow"
                        href="../wp-login3419.html?action=wordpress_social_authenticate&amp;mode=login&amp;provider=Facebook&amp;redirect_to=http%3A%2F%2Faonetheme.com%2Fextend%2Fsignup%2F"
                        title="Connect with Facebook" class="wp-social-login-provider wp-social-login-provider-facebook"
                        data-provider="Facebook">
                        <img alt="Facebook" title="Connect with Facebook"
                          src="../wp-content/plugins/wordpress-social-login/assets/img/32x32/wpzoom/facebook.png" />
                      </a>

                      <a rel="nofollow"
                        href="../wp-login8ac5.html?action=wordpress_social_authenticate&amp;mode=login&amp;provider=Google&amp;redirect_to=http%3A%2F%2Faonetheme.com%2Fextend%2Fsignup%2F"
                        title="Connect with Google" class="wp-social-login-provider wp-social-login-provider-google"
                        data-provider="Google">
                        <img alt="Google" title="Connect with Google"
                          src="../wp-content/plugins/wordpress-social-login/assets/img/32x32/wpzoom/google.png" />
                      </a>

                      <a rel="nofollow"
                        href="../wp-loginebb0.html?action=wordpress_social_authenticate&amp;mode=login&amp;provider=Twitter&amp;redirect_to=http%3A%2F%2Faonetheme.com%2Fextend%2Fsignup%2F"
                        title="Connect with Twitter" class="wp-social-login-provider wp-social-login-provider-twitter"
                        data-provider="Twitter">
                        <img alt="Twitter" title="Connect with Twitter"
                          src="../wp-content/plugins/wordpress-social-login/assets/img/32x32/wpzoom/twitter.png" />
                      </a>

                    </div>

                    <div class="wp-social-login-widget-clearing"></div>

                  </div>


                </div>
          </div>



        </div>

      </div>
    </div>
  </div>
</div>
@endsection