@extends('new_layout.template')
@section('content')
<div class="page-content">
    <!-- inner page banner END -->
    <!-- Breadcrumb  Templates Start -->

    <div class="breadcrumb-row">
        <div class="container">
            <ul class="list-inline">
                <li><a href="#">Home</a></li>
                <li>Services</li>
                <li>{{ $model[0]->name }}</li>
            </ul>
        </div>
    </div>
    <!-- Breadcrumb  Templates End -->
    <!-- contact area -->
    <div class="container">
        <div class="section-content">
            <div class="row">
                <div class="col-md-12">
                    <!-- Contact Info Start -->

                    <div class="padding-30 bg-white margin-b-30 clearfix sf-rouned-box">
                        <h2>{{ $model[0]->name }}</h2>
                        {!! $model[0]->description !!}
                        <div class="col-md-4 col-sm-4 service-list_item-categories">
                            <h4>Unique Benefits</h4>
                            {!! $model[0]->unique_benefits !!}
                        </div>

                        <div class="col-md-8 col-sm-8 service-category-hasib">
                            <h4>Service Category</h4>
                            {!! $model[0]->service_category !!}
                        </div>
                    </div>
                    <!-- Contact Info Start -->
                </div>
            </div>
        </div>
    </div>
    <!-- contact area  END -->
</div>
@endsection