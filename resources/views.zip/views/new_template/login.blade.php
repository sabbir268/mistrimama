@extends('new_layout.template')
@section('content')
<div class="page-content">
    <!-- inner page banner -->
    <!-- Breadcrumb  Templates Start -->

<div class="breadcrumb-row">
  <div class="container">
    <ul class="list-inline">
      <li><a href="../index.html">
        Home        </a></li>
      <li>Login</li>    </ul>
  </div>
</div>
<!-- Breadcrumb  Templates End -->
  <!-- Left & right section start -->
  
 <div class="section-content profiles-content" >
    <div class="container">
      <div class="row">
      	                  <!-- Left part start -->
        <div class="col-md-12">
                    <!-- Login Template -->

 
  <div class="padding-20  margin-b-30  bg-white sf-rouned-box clearfix">
		<div class="loginform_dx row"><form class="loginform_page" method="post" action="{{route('user.do-login')}}">
            {{csrf_field()}}
            <div class="col-md-12">
              <div class="form-group">
                <div class="input-group"> <i class="input-group-addon fa fa-user"></i>
                  <input name="email" type="text" class="form-control" placeholder="Email">
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <div class="input-group"> <i class="input-group-addon fa fa-lock"></i>
                  <input name="password" type="password" class="form-control" placeholder="Password">
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <input type="submit" class="btn btn-primary btn-block" name="user-login" value="Login" />
              </div>
            </div>
            <div class="col-md-12 text-center"> <small><a href="../signup/index.html" >
              Don&#039;t have an account?
              </a> | <a href="javascript:;" class="fp_bx">
              Forgot Password
              </a></small> </div>
          </form></div></div><div class="forgotpasswordform_dx hidden"><form class="forgotpassform_page" method="post">
            <div class="col-md-12">
              <div class="form-group">
                <div class="input-group"> <i class="input-group-addon fa fa-user"></i>
                  <input name="fp_user_login" type="text" class="form-control" placeholder="Username or E-mail:">
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <input type="hidden" name="action" value="resetpass" />
                <input type="submit" class="btn btn-primary btn-block" name="user-login" value="Get New Password" />
              </div>
            </div>
            <div class="col-md-12 text-center"> <small><a href="../signup/index.html" class="regform">
              Don&#039;t have an account?
              </a> | <a href="javascript:;" class="lg_bx">
              Already Registered?
              </a></small> </div>
          </form></div>
                    
          		            		  		  
		  		  
        </div>
        <!-- Left part END -->
        
      </div>
    </div>
  </div>
  <!-- Left & right section  END -->
</div>
@endsection